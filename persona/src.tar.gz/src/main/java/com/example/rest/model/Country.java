package com.example.rest.model;

public class Country {
	
	String name;
	String code;

}
