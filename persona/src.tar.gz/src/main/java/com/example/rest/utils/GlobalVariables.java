package com.example.rest.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.example.rest.model.PersonaName;
import com.example.rest.persistence.FileHandler;

public class GlobalVariables {

	public static final int CIF_RECORD_LENGTH = 13;

	// static ArrayList<String> countries;
	public static final String[] GENDER_LIST = { "male", "female" };
	public static final String[] AGE_LIST = { "13-17", "18-24", "25-34", "35-44", "45-54", "55-64", "65+" };
	// static boolean[] selectedPhotos = null;
	public static Map<String, Integer> genderMap = null;
	public static Map<String, Integer> ageMap = null;
	public static Map<String, Integer> regionMap = null;
	public static Map<String, Integer> demographicsMap = null;

	public static ArrayList<ArrayList<Integer>> regionRelations = null;

	public static final String[] ALL_SOCIAL_METRICS = { "FACEBOOK_INTERACTIONS", "TWITTER_INTERACTIONS",
			"FACEBOOK_POSITIVE", "FACEBOOK_NEGATIVE", "TWITTER_POSITIVE", "TWITTER_NEGATIVE" };

	public static final String[] SOCIAL_METRICS = { "FACEBOOK_POSITIVE", "FACEBOOK_NEGATIVE", "TWITTER_POSITIVE",
			"TWITTER_NEGATIVE" };

	public static final String[] REGIONS = { "African", "Caribbean", "Central Asia", "East Asia",
			"Europe & US & North Asia", "Gulf", "Latin", "Middle Eastern", "Pacific Ocean", "South Asia",
			"SouthEast Asia" };

	// public static final int FILTERATION_THRESHOLD = 6000;

	public static ArrayList<String> demographicsList = null;

	public static int[][] allSocialMatrix = null;

	public static ArrayList<String> allSocialdemographicsList;

	public static Map<String, Integer> allSocialDemographicsMap;

	public static Map<String, String> cityCountryMap;

	public static ArrayList<PersonaName> personaNames;

	public static void init() {

		demographicsList = new ArrayList<>();

		genderMap = new HashMap<>();
		ageMap = new HashMap<>();
		regionMap = new HashMap<>();

		demographicsMap = new HashMap<>();
		;

		for (int i = 0; i < GENDER_LIST.length; i++) {
			genderMap.put(GENDER_LIST[i], i);
		}

		for (int i = 0; i < AGE_LIST.length; i++) {
			ageMap.put(AGE_LIST[i], i);
		}

		for (int i = 0; i < REGIONS.length; i++) {
			regionMap.put(REGIONS[i], i);
		}

		regionRelations = new ArrayList<>();

		int numOfRegions = regionMap.size();

		for (int i = 0; i < numOfRegions; i++) {
			ArrayList<Integer> arrayList = new ArrayList<>();
			switch (i) {
			case 0:
				// Africation until now there is no similar region
				break;
			case 1: // Caribbean
				arrayList.add(regionMap.get("Latin"));
				break;
			case 2: // Central Asia
				arrayList.add(regionMap.get("East Asia"));
				arrayList.add(regionMap.get("South Asia"));
				arrayList.add(regionMap.get("SouthEast Asia"));
				break;
			case 3: // East Asia
				arrayList.add(regionMap.get("Central Asia"));
				arrayList.add(regionMap.get("South Asia"));
				arrayList.add(regionMap.get("SouthEast Asia"));
				break;
			case 4: // Europe & US & North Asia
				arrayList.add(regionMap.get("Middle Eastern"));
				break;
			case 5: // Gulf
				arrayList.add(regionMap.get("Middle Eastern"));
				break;
			case 6: // Latin
				arrayList.add(regionMap.get("Caribbean"));
				break;
			case 7: // Middle Eastern
				arrayList.add(regionMap.get("Europe & US & North Asia"));
				break;
			case 8: // Pacific Ocean
				arrayList.add(regionMap.get("South Asia"));
				arrayList.add(regionMap.get("SouthEast Asia"));
				break;
			case 9:// South Asia
				arrayList.add(regionMap.get("Central Asia"));
				arrayList.add(regionMap.get("East Asia"));
				arrayList.add(regionMap.get("SouthEast Asia"));
				break;
			case 10:// SouthEast Asia
				arrayList.add(regionMap.get("Central Asia"));
				arrayList.add(regionMap.get("East Asia"));
				arrayList.add(regionMap.get("South Asia"));
				break;
			default:
				break;
			}
			regionRelations.add(arrayList);
		}

		cityCountryMap = new HashMap<>();
		cityCountryMap.put("cairo", "egypt");
		cityCountryMap.put("alexandria", "egypt");
		cityCountryMap.put("riyadh", "saudi arabia");
		cityCountryMap.put("jeddah", "saudi arabia");
		cityCountryMap.put("dubai", "united arab emirates");
		cityCountryMap.put("abu dhabi", "united arab emirates");
		cityCountryMap.put("abo dhabi", "united arab emirates");
		cityCountryMap.put("doha", "qatar");

		personaNames = FileHandler.readPersonaNames();
	}

}
