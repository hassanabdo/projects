package com.example.rest.utils;

public enum RequestType {
	NMF, SVD
}
