package com.example.rest.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.example.rest.persistence.DatabaseHandler;
import com.example.rest.persistence.FileHandler;
import com.example.rest.utils.GlobalVariables;
import com.example.rest.utils.HelperMethods;

public class DataInitializer {

	public static void collectData() {

		GlobalVariables.init();

		ArrayList<String> cities = DatabaseHandler.getDistinctCities();

		HashSet<String> normalizedCitiesNamesSet = new HashSet<String>();

		for (String city : cities) {
			// System.out.println(city);
			normalizedCitiesNamesSet.add(HelperMethods.getNormalizedCityName(city));
		}

		int counter = 0;
		for (String city : normalizedCitiesNamesSet) {
			for (String age : GlobalVariables.AGE_LIST) {
				for (String gender : GlobalVariables.GENDER_LIST) {
					StringBuilder builder = new StringBuilder();
					builder.append(city).append(",").append(age).append(",").append(gender);
					GlobalVariables.demographicsMap.put(builder.toString(), counter);
					GlobalVariables.demographicsList.add(builder.toString());
					counter++;
				}
			}
		}

		GlobalVariables.allSocialMatrix = new int[GlobalVariables.demographicsList
				.size()][GlobalVariables.SOCIAL_METRICS.length];

		createMatrices();
	}

	public static void createMatrices() {
		ArrayList<String[]> recordArrayList = DatabaseHandler.getCIFRecords();
		int[] sumArray_all_social = new int[GlobalVariables.demographicsList.size()];
		
		for (String[] record : recordArrayList) {
			int i = 0;
			String city = HelperMethods.getNormalizedCityName(record[i++]);
			String age = HelperMethods.getNormalizedAgeName(record[i++]);
			String gender = HelperMethods.getNormalizedGenderName(record[i++]);
//			String activity = HelperMethods.getNormalizedActivityName(record[i++]);
			String facebook_id = record[i++];
			String twitter_id = record[i++];
//			String semantic = record[i++];
//			String fb_inter = record[i++];
//			String tw_inter = record[i++];
			String fb_pos = record[i++];
			String fb_neg = record[i++];
			String tw_pos = record[i++];
			String tw_neg = record[i++];

			StringBuilder builder = new StringBuilder();
			builder.append(city).append(",").append(age).append(",").append(gender);
			int rowIndex = GlobalVariables.demographicsMap.get(builder.toString());

//			if (fb_inter != null) {
//				GlobalVariables.allSocialMatrix[rowIndex][0] += Integer.parseInt(fb_inter);
//				sumArray_all_social[rowIndex] += Integer.parseInt(fb_inter);
//			}
//			if (tw_inter != null) {
//				GlobalVariables.allSocialMatrix[rowIndex][1] += Integer.parseInt(tw_inter);
//				sumArray_all_social[rowIndex] += Integer.parseInt(tw_inter);
//			}
			if (fb_pos != null) {
				GlobalVariables.allSocialMatrix[rowIndex][0] += Integer.parseInt(fb_pos);
				sumArray_all_social[rowIndex] += Integer.parseInt(fb_pos);
			}
			if (fb_neg != null) {
				GlobalVariables.allSocialMatrix[rowIndex][1] += Integer.parseInt(fb_neg);
				sumArray_all_social[rowIndex] += Integer.parseInt(fb_neg);
			}
			if (tw_pos != null) {
				GlobalVariables.allSocialMatrix[rowIndex][2] += Integer.parseInt(tw_pos);
				sumArray_all_social[rowIndex] += Integer.parseInt(tw_pos);
			}
			if (tw_neg != null) {
				GlobalVariables.allSocialMatrix[rowIndex][3] += Integer.parseInt(tw_neg);
				sumArray_all_social[rowIndex] += Integer.parseInt(tw_neg);
			}
		}

		FileHandler.write2DArray(GlobalVariables.allSocialMatrix, "OLD_ALL_SOCIAL_MATRIX.txt");
//		for (int i = 0; i < sumArray_all_social.length; i++) {
//			System.out.println("i = "+i+", key = "+GlobalVariables.demographicsList.get(i)
//				+", rowSum = "+sumArray_all_social[i]);
//		}
		filter(sumArray_all_social);
	}

	private static void filter(int[] sumArray_all_social) {
		int threshold = getThreshold();
		System.out.println(">>>>> Threshold = "+threshold);
		int newAllSocialRecordNum = getNumOfRecords(sumArray_all_social,threshold);
		System.out.println(">>>>>>>>>>> newAllSocialRecordNum "+newAllSocialRecordNum);
		
		ArrayList<String> demographicsList_allSocial = new ArrayList<>();
		int[][] matrix_allSocial = new int[newAllSocialRecordNum][GlobalVariables.SOCIAL_METRICS.length];
		Map<String, Integer> demographicsMap_allSocial = new HashMap<>();

		filterMatrices(sumArray_all_social, GlobalVariables.allSocialMatrix, GlobalVariables.demographicsList,
				demographicsList_allSocial, matrix_allSocial, demographicsMap_allSocial, threshold);
		GlobalVariables.allSocialMatrix = matrix_allSocial;
		GlobalVariables.allSocialdemographicsList = demographicsList_allSocial;
		GlobalVariables.allSocialDemographicsMap = demographicsMap_allSocial;

	}

	private static int getThreshold() {
		int[][] array = GlobalVariables.allSocialMatrix;
		long sum = 0;
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				sum += array[i][j];
			}
		}
		return (int)((sum/array.length)*1.2);
	}

	private static int getNumOfRecords(int[] sumArray, int threshold) {
		int numOfNewRows = 0;
		for (int i = 0; i < sumArray.length; i++) {
			if (sumArray[i] > threshold)
				numOfNewRows++;
		}
		return numOfNewRows;
	}

	private static void filterMatrices(int[] sumArray, int[][] matrix, ArrayList<String> demographicsList,
			ArrayList<String> demographicsListNew, int[][] matrixNew, Map<String, Integer> demographicsMapNew, int threshold) {

//		System.out.println("///////////////////////////////////////////////////////");
		int k = 0;
		for (int i = 0; i < matrix.length; i++) {
			if (sumArray[i] > threshold) {
				for (int j = 0; j < matrixNew[k].length; j++) {
					matrixNew[k][j] = matrix[i][j];
				}
				demographicsMapNew.put(demographicsList.get(i), k);
				demographicsListNew.add(demographicsList.get(i));
				
//				System.out.println("k = "+k+", key = "+demographicsListNew.get(k)+", old index = "+i);
				
				k++;
			}
		}

	}

}
