package com.example.rest.services;

import java.util.ArrayList;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.example.rest.controller.Controller;
import com.example.rest.model.Persona;
import com.example.rest.utils.RequestType;

@Path("/system")
public class MyResource {
	
	@POST
	@Path("svd/")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Persona> getPersonaTwitter() {
    	System.out.println("get persona TWITTER");
		return Controller.getPersona(0, RequestType.SVD);
	}
	
	@POST
	@Path("allSocial/{num}")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Persona> getPersonaAllSocial(@PathParam("num") long n) {
    	System.out.println("get persona ALL_SOCIAL");
		return Controller.getPersona((int)n, RequestType.NMF);
	}
}
