package com.example.rest.utils;

import java.io.IOException;

import org.json.JSONArray;

import com.google.gson.JsonObject;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

public class HelperMethods {
	public static String getNormalizedCityName(String city) {
		String normalizedCityName = city.toLowerCase();
		
		OkHttpClient client = new OkHttpClient();
		
//		Request request = new Request.Builder()
//		  .url("https://maps.googleapis.com/maps/api/geocode/json?address="+normalizedCityName+"&key=AIzaSyBG5Ju3lBax5avL5TNPiIOD4Y0OXKlLE7A")
//		  .get()
//		  .addHeader("Cache-Control", "no-cache")
//		  .addHeader("Postman-Token", "b6294cc4-4293-c9ec-d641-6e0a5402d620")
//		  .build();

//		client.newCall(request).enqueue(new Callback() {
//			
//			@Override
//			public void onResponse(Response response) throws IOException {
//				// TODO Auto-generated method stub
////				System.out.println(response.body().string());
//				numOfRes++;
////				String jsonData = response.body().string();
////				org.json.JSONObject jsonObject = new org.json.JSONObject(jsonData);
////				JSONArray Jarray = jsonObject.getJSONArray("results");
////				if(Jarray.length() > 0) {
////					org.json.JSONObject obj = Jarray.getJSONObject(0);
////					org.json.JSONArray arr = obj.getJSONArray("address_components");
////					if(arr.length() > 0) {
////						
////					}
////				}
//				
//			}
//			
//			@Override
//			public void onFailure(Request response, IOException arg1) {
//				// TODO Auto-generated method stub
//				numOfErr++;
//			}
//		});
		
		return normalizedCityName;
	}
	
	public static String getNormalizedAgeName(String age) {
		return age;
	}
	
	public static String getNormalizedActivityName(String activity) {
		return activity;
	}
	
	public static String getNormalizedGenderName(String gender) {
		return gender;
	}
	

}
