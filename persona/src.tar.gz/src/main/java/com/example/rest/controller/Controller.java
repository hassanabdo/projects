package com.example.rest.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.ujmp.core.Matrix;

import com.example.rest.Main;
import com.example.rest.model.Persona;
import com.example.rest.model.PersonaName;
import com.example.rest.model.Region;
import com.example.rest.persistence.FileHandler;
import com.example.rest.utils.GlobalVariables;
import com.example.rest.utils.RequestType;

public class Controller {

	public static ArrayList<Persona> getPersona(int n, RequestType type) {

		/*
		 * calling r function with n.
		 */
		double[][] wMatrix = null;
		double[][] hMatrix = null;
		double[] personaPowers = null;
		if (type == RequestType.NMF) {
			runRFunction(n);
			wMatrix = new double[GlobalVariables.allSocialMatrix.length][n];
			hMatrix = new double[n][GlobalVariables.SOCIAL_METRICS.length];

			FileHandler.readMatrix(wMatrix, 0);
			FileHandler.readMatrix(hMatrix, 1);
		} else {
			Matrix originalMatrix = Matrix.Factory.zeros(GlobalVariables.allSocialMatrix.length,
					GlobalVariables.SOCIAL_METRICS.length);

			for (int i = 0; i < GlobalVariables.allSocialMatrix.length; i++) {
				for (int j = 0; j < GlobalVariables.allSocialMatrix[i].length; j++) {
					originalMatrix.setAsInt(GlobalVariables.allSocialMatrix[i][j], i, j);
				}
			}
			Matrix[] svd = null;
			try {
				svd = originalMatrix.svd();
			} catch (Exception e) {
				e.printStackTrace();
			}

			List<Double> list = new ArrayList<>();
			// the diagonal matrix is sorted in decreasing order
			for (int r = 0; r < svd[1].getRowCount(); r++) {
//				if (svd[1].getAsDouble(r, r) > 1) {
					list.add(svd[1].getAsDouble(r, r));
//				}
			}
			double[] personaPowersRaw = new double[list.size()];
			int i = 0;
			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
				personaPowersRaw[i++] = (double) iterator.next();
			}
			personaPowers = calculateSoftMaxFunc(personaPowersRaw);

			System.out.println("wMatrix " + svd[0].getRowCount() + ", " + svd[0].getColumnCount());
			wMatrix = new double[(int) svd[0].getRowCount()][(int) svd[0].getColumnCount()];
			for (int r = 0; r < svd[0].getRowCount(); r++) {
				for (int c = 0; c < svd[0].getColumnCount() && c < personaPowers.length; c++) {
					wMatrix[r][c] = svd[0].getAsDouble(r, c);
				}
			}
			for (int r = 0; r < svd[1].getRowCount(); r++) {
				for (int c = 0; c < svd[1].getColumnCount(); c++) {
					System.out.print(svd[1].getAsDouble(r, c) + " ");
				}
				System.out.println();
			}
			Matrix newH = svd[2].transpose();
			System.out.println("hMatrix " + newH.getRowCount() + ", " + newH.getColumnCount());
			hMatrix = new double[(int) newH.getRowCount()][(int) newH.getColumnCount()];
			for (int r = 0; r < newH.getRowCount() && r < personaPowers.length; r++) {
				for (int c = 0; c < newH.getColumnCount(); c++) {
					hMatrix[r][c] = newH.getAsDouble(r, c);
				}
			}

			FileHandler.write2DArray(wMatrix, "svd_wMatrix.json");
			FileHandler.write2DArray(hMatrix, "svd_hMatrix.json");
		}

		ArrayList<String> persona_demographics = new ArrayList<String>();
		calculatePersonaDemographics(persona_demographics, wMatrix, type);

		ArrayList<String> persona_least_topics = new ArrayList<String>();
		calculatePersonaLeastOrMostImportantTopic(persona_least_topics, hMatrix, type, true);

		ArrayList<String> persona_most_topics = new ArrayList<String>();
		calculatePersonaLeastOrMostImportantTopic(persona_most_topics, hMatrix, type, false);

		double[] persona_fb_pos = calculatePersonaImpression(hMatrix, 0);
		double[] persona_fb_neg = calculatePersonaImpression(hMatrix, 1);
		double[] persona_tw_pos = calculatePersonaImpression(hMatrix, 2);
		double[] persona_tw_neg = calculatePersonaImpression(hMatrix, 3);

		ArrayList<String> persona_names = new ArrayList<String>();
		getPersonaNames(persona_names, persona_demographics);

		ArrayList<Persona> personas_arrayList = new ArrayList<Persona>();
		for (int i = 0; i < persona_demographics.size(); i++) {
			Persona persona = new Persona();
			persona.setId(i);
			String[] arr = persona_demographics.get(i).split(",");
			persona.setGender(arr[2]);
			persona.setAge(arr[1]);
			persona.setCity(arr[0]);
			persona.setCountry(GlobalVariables.cityCountryMap.get(arr[0]));
			persona.setName(persona_names.get(i));

			DecimalFormat df2 = new DecimalFormat(".##");
			persona.setFbPos(df2.format(persona_fb_pos[i] * 100) + " %");
			persona.setFbNeg(df2.format(persona_fb_neg[i] * 100) + " %");
			persona.setTwPos(df2.format(persona_tw_pos[i] * 100) + " %");
			persona.setTwNeg(df2.format(persona_tw_neg[i] * 100) + " %");

			persona.setMostTopic(persona_most_topics.get(i));
			persona.setLeastTopic(persona_least_topics.get(i));

			if (personaPowers != null) {
				persona.setPersonaPower(df2.format(personaPowers[i] * 100) + " %");
			}

			personas_arrayList.add(persona);
		}

		extractPersonaPhotos(personas_arrayList);

		return personas_arrayList;

	}

	// matrix normalization is needed
	private static double[] calculatePersonaImpression(double[][] hMatrix, int colNum) {
		double[] array = new double[hMatrix.length];
		for (int i = 0; i < array.length; i++) {
			array[i] = hMatrix[i][colNum];
		}
		return calculateSoftMaxFunc(array);
	}

	private static double[] calculateSoftMaxFunc(double[] array) {
		double[] z_exp = new double[array.length];
		double[] normVec = normalizeVector(array);
		for (int i = 0; i < normVec.length; i++) {
			z_exp[i] = Math.exp(normVec[i]);
		}
		double sum_z_exp = 0;
		for (int i = 0; i < z_exp.length; i++) {
			sum_z_exp += z_exp[i];
		}
		double[] softmax = new double[array.length];
		for (int i = 0; i < softmax.length; i++) {
			softmax[i] = z_exp[i] / sum_z_exp;
		}
		return softmax;
	}

	private static double[] normalizeVector(double[] vec) {
		double[] normVec = new double[vec.length];
		
		double mean = 0;
		for (int i = 0; i < vec.length; i++) {
			mean += vec[i];
		}
		mean /= vec.length;
		System.out.println("mean "+mean);
		double stdDev = 0;
		for (int i = 0; i < vec.length; i++) {
			stdDev += Math.pow(vec[i]-mean, 2);
		}
		double segma = Math.sqrt(stdDev/vec.length);
		System.out.println("segma "+segma);
		for (int i = 0; i < vec.length; i++) {
			normVec[i] = (vec[i]-mean)/segma;
		}
		return normVec;
	}

	private static void getPersonaNames(ArrayList<String> persona_names, ArrayList<String> persona_demographics) {

		for (Iterator<String> iterator = persona_demographics.iterator(); iterator.hasNext();) {
			String string = iterator.next();
			String[] arr = string.split(",");
			System.out.println(arr[0]);
			String country = GlobalVariables.cityCountryMap.get(arr[0]);
			for (PersonaName personaName : GlobalVariables.personaNames) {
				if (personaName.getCountry_name().equalsIgnoreCase(country)) {
					String[] names = personaName.getNames_list();
					if (arr[2].equalsIgnoreCase(GlobalVariables.GENDER_LIST[0])) {
						persona_names.add(names[0]);
					} else {
						persona_names.add(names[1]);
					}
				}
			}
		}

	}

	private static void calculatePersonaLeastOrMostImportantTopic(ArrayList<String> persona_topics, double[][] hMatrix,
			RequestType type, boolean isLeast) {
		for (int i = 0; i < hMatrix.length; i++) {
			if (isLeast) {
				String leastTopic = "";
				leastTopic += GlobalVariables.SOCIAL_METRICS[2] + " = " + hMatrix[i][2];
				leastTopic += " / ";
				leastTopic += GlobalVariables.SOCIAL_METRICS[3] + " = " + hMatrix[i][3];
				persona_topics.add(leastTopic);
			} else {
				String mostTopic = "";
				mostTopic += GlobalVariables.SOCIAL_METRICS[0] + " = " + hMatrix[i][0];
				mostTopic += " / ";
				mostTopic += GlobalVariables.SOCIAL_METRICS[1] + " = " + hMatrix[i][1];
				persona_topics.add(mostTopic);
			}

		}
	}

	private static void calculatePersonaDemographics(ArrayList<String> persona_demographics, double[][] wMatrix,
			RequestType type) {
		Set<Integer> personasSet = new HashSet<>();
		for (int col = 0; col < wMatrix[0].length; col++) {

			double[] valArray = new double[wMatrix.length];
			int[] indexArray = new int[wMatrix.length];

			for (int row = 0; row < indexArray.length; row++) {
				valArray[row] = wMatrix[row][col];
				indexArray[row] = row;
			}

			bubbleSort(valArray, indexArray);

			for (int i = 0; i < indexArray.length; i++) {
				if (!personasSet.contains(indexArray[i])) {
					persona_demographics.add(GlobalVariables.allSocialdemographicsList.get(indexArray[i]));
					personasSet.add(indexArray[i]);
					break;
				}
			}

			// int row = 0;
			//
			// double max = wMatrix[row][col];
			// int maxIndex = row;
			//
			// for (row = 1; row < wMatrix.length; row++) {
			//
			// if (wMatrix[row][col] > max) {
			// max = wMatrix[row][col];
			// maxIndex = row;
			// }
			//
			// }

			// persona_demographics.add(GlobalVariables.allSocialdemographicsList.get(maxIndex));
			// personasSet.add(maxIndex);
		}

	}

	private static void bubbleSort(double[] arr, int[] indexes) {
		int n = arr.length;
		double temp = 0;
		int tmpIndex = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < (n - i); j++) {
				if (arr[j - 1] < arr[j]) {
					// swap elements
					temp = arr[j - 1];
					arr[j - 1] = arr[j];
					arr[j] = temp;

					tmpIndex = indexes[j - 1];
					indexes[j - 1] = indexes[j];
					indexes[j] = tmpIndex;
				}
			}
		}
	}

	private static void extractPersonaPhotos(ArrayList<Persona> personas_arrayList) {
		ArrayList<Region> regions = FileHandler.readRegionsJSON();
		// Generate photos
		HashSet<String> set = new HashSet<String>();
		for (Persona per : personas_arrayList) {
			// String country = GlobalVariables.cityCountryMap.get(per.getCity());
			String per_region = getRegion(per.getCountry(), regions);
			String srcPath = per_region + "/" + per.getGender() + "/" + per.getAge();
			// per.setPhoto(srcPath);
			System.out.println("0 " + srcPath);

			String srcPath2 = getPhoto(per_region, per.getGender(), per.getAge(), set);
			per.setPhoto(srcPath2);
			System.out.println("1 " + srcPath2);
			System.out.println("??????????????????????????");
		}

	}

	private static String getPhoto(String region, String gender, String age, HashSet<String> set) {
		int regionIndex = GlobalVariables.regionMap.get(region);
		int genderIndex = GlobalVariables.genderMap.get(gender);
		int ageIndex = GlobalVariables.ageMap.get(age);

		String key = calculateIndex(genderIndex, ageIndex, regionIndex);

		if (!set.contains(key)) {
			set.add(key);
			return region + "/" + gender + "/" + age;
		}
		// see the two surrounding ages
		if (ageIndex > 0) { // see the earlier
			key = calculateIndex(genderIndex, ageIndex - 1, regionIndex);
			if (!set.contains(key)) {
				set.add(key);
				return region + "/" + gender + "/" + getKeyFromMap("age", ageIndex - 1);
			}
		}
		if (ageIndex < GlobalVariables.ageMap.size() - 1) {
			key = calculateIndex(genderIndex, ageIndex + 1, regionIndex);
			if (!set.contains(key)) {
				set.add(key);
				return region + "/" + gender + "/" + getKeyFromMap("age", ageIndex + 1);
			}
		}
		ArrayList<Integer> neighbours = GlobalVariables.regionRelations.get(GlobalVariables.regionMap.get(region));
		for (Iterator iterator = neighbours.iterator(); iterator.hasNext();) {
			Integer altRegionIndex = (Integer) iterator.next();
			key = calculateIndex(genderIndex, ageIndex, altRegionIndex);
			if (!set.contains(key)) {
				set.add(key);
				return getKeyFromMap("region", altRegionIndex) + "/" + gender + "/" + age;
			}
		}
		return "";
	}

	private static String calculateIndex(int gender, int age, int region) {
		return String.valueOf(gender) + "-" + String.valueOf(age) + "-" + String.valueOf(region);
	}

	private static String getKeyFromMap(String type, int value) {
		if (type.equalsIgnoreCase("age")) {
			return GlobalVariables.AGE_LIST[value];
		}
		return GlobalVariables.REGIONS[value];
	}

	private static String getRegion(String country, ArrayList<Region> regions) {
		for (Region region : regions) {
			String[] countries = region.getCountries();
			for (int i = 0; i < countries.length; i++) {
				if (countries[i].contains(country) || countries[i].equalsIgnoreCase(country)) {
					return region.getEthnicity();
				}
			}
		}
		System.err.println("No such region for " + country);
		return null;
	}

	public static void readFromFile(ArrayList<String> arrayList, String fileName) {
		JSONParser parser = new JSONParser();
		try {
			File file = new File(Main.projectPath + fileName + ".json");
			FileReader reader = new FileReader(file);
			JSONArray a = (JSONArray) parser.parse(reader);
			for (Object o : a) {
				String str;
				try {
					str = (String) o;
				} catch (Exception e) {
					// TODO: handle exception
					str = ((Long) o) + "";
				}

				arrayList.add(str);

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void runRFunction(int n) {
		int typeNum = 3;

		String command = null;
		// System.out.println(command);
		try {
			RConnection connection = new RConnection();// make a new local connection on default port (6311)
			command = "setwd('" + Main.projectPath + "')";
			REXP rResponseObject = null;
			try {
				rResponseObject = connection.parseAndEval("try(eval(" + command + "),silent=TRUE)");
			} catch (REXPMismatchException e) {
				e.printStackTrace();
			}
			if (rResponseObject.inherits("try-error")) {
				System.out.println("R Serve Eval Exception : " + rResponseObject.asString());
			} else {
				System.out.println(connection.eval("getwd()").asString());

				try {
					rResponseObject = connection
							.parseAndEval("try(eval(" + "source('NMFCreation_new.r')" + "),silent=TRUE)");
				} catch (REXPMismatchException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (rResponseObject.inherits("try-error")) {
					System.out.println("R Serve Eval Exception : " + rResponseObject.asString());
				} else {
					rResponseObject = connection.parseAndEval(
							"try(eval(" + "persona_function(" + n + "," + typeNum + ")" + "),silent=TRUE)");
					if (rResponseObject.inherits("try-error")) {
						System.out.println("R Serve Eval Exception : " + rResponseObject.asString());
					} else {
						System.out.println("done successfully");
					}
				}
			}

		} catch (REngineException e) {
			e.printStackTrace();
		} catch (REXPMismatchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
